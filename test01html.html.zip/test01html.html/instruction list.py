#1.Start from Neutral Position (N)
MoveTo(N);
#Pick Mint Leaves (Point A)
MoveTo(A);
Pick();
#Add Lime Juice (Point B):
MoveTo(B);
Pour();
#Pour Rum (Point C):
MoveTo(C);
Pour();
#Top with Soda Water (Point D):
MoveTo(D);
Pour();
#Return to Neutral Position (N):
MoveTo(N);




